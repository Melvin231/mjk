import sqlite3
import os
import platform

def function():
    con = sqlite3.connect('Attendance.db')
    m = con.cursor()
    
    print('''\n\n
===================================== HELLO WELCOME TO MY DATABASE PROGRAM =======================================
=====================================     DEVELOP BY MELVIN JOJO KONNEH    =======================================
         ''')

    print('''\n\n              WELCOME PLEASE CHOOSE FROM THE BELOW OPTION

    Enter 1 To Add New Student

    Enter 2 To Remove Student

    Enter 3 To Search For Student

    Enter 4 To View DaaBase
             ''')
    try:
        user = int(input('\n Type a Number from the Option Above: '))
    except ValueError:
        exit('\nPlease Enter a Number')
    else:
        print('\n')

    if(user == 1):
        s_name = input('Enter Student Name: ')
        s_id = input('Enter Student Id: ')
        s_class = input('Enter Student Class: ')
        s_sec = input('Enter Student Section: ')
        m.execute('''INSERT INTO Attendance
            VALUES (?,?,?,?)''', (s_name, s_id, s_class, s_sec))
        print('\n Student Added Successfully ')
        con.commit()
        con.close()

    elif(user == 2):
        n_n = input('type Student Name to Delete: ')
        n_n = n_n.strip()
        m.execute("DELETE FROM Attendance WHERE Name = ?;", [n_n])
        print("\n '{}' was deleted from your database".format(n_n))
        con.commit()
        con.close()
        
    elif(user == 3):
        s_s = input('\n Search: Enter Student Name : ')
        s_s = s_s.strip()
        m.execute("SELECT * FROM Attendance WHERE Name = ?;", [s_s])
        print(m.fetchall())
        con.commit()
        con.close()

    elif(user == 4):
        l = m.execute('SELECT * from Attendance')
        for row in l:
            print('\nName: ', row[0])
            print('Id: ', row[1])
            print('Class: ', row[2])
            print('Section: ', row[3], '\n')
        con.commit()
        con.close()

    elif(user < 1 or user > 4):
        print('\nPlease Enter Valid Option')

def run():
    r = input("\nDo You Want To Run Y/N: ")
    if(r.lower() == 'y'):
        if(platform.system() == "Winows"):
            print(os.system('cls'))
        else:
            print(os.system('clear'))
        function()
        run()
    else:
        quit()
run()
    

